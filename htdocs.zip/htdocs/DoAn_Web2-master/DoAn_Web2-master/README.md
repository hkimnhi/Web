# DoAn_Web2

Donate? Muốn hỗ trợ mình 1 ly cafe <3 [Donate here](https://github.com/HoangTran0410/HoangTran0410/blob/main/DONATE.md)

## Demo
[Youtube Video](https://www.youtube.com/watch?v=GlSDvBLYsOc&t)

## Các bước cài đặt:

1. Mở xampp, apache, MySQL
2. Bỏ folder project vào xampp htdocs
2. Tạo mới database tên web2 trong phpmyadmin, rồi import file web2.sql vào
3. Chạy trang web từ localhost của xampp và tận hưởng

## Tài khoản admin

user: Admin

pass: 123

## Tips
Nếu có lỗi lấy dữ liệu, có thể do cài đặt kết nối database gặp bị sai, bạn vào BackEnd/ConnectionDB/DB_driver.php chỉnh lại $host, $DbName, $user, $pass cho đúng với cài đặt phpmyadmin của máy bạn.
