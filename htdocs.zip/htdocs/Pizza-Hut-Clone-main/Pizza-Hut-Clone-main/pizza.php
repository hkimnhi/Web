<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pizza hut clone</title>
    <link rel="Shortcut icon" type="image" href="images/pizza hut logo.png">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/utility.css">
    <script defer src="js/script.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
     <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script> -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.3/Chart.min.js"></script> -->
    <script src="../pizza.js"></script>

 
</head>
<body>
    <header>
        <nav>
            <div class="logo"> <a href="index.html"> <img src="images/pizza hut logo 2.png" ></a></div>
            <div class="basketlogo " onclick="basketshow()"><img src="images/icons/basket.webp" alt=""></div>
            <div class="flex-basket hide">
                <h2>Your Basket</h2>
                <p id="voucher">Apply Voucher code or Gift Card  ></p>
                <a>Your basket looks a little empty. Why not check out some of <u id="underline">our unbeatable deals?</u>
                <button id="checkout">Checkout</button>
            </div>
            <ul>
                <div class="itembar"> 
                    <a class="boxitems" href="index.html">Deals</a>
                    <a class="boxitems" href="pizza.php">Pizzas</a>
                    <a class="boxitems" href="sides.html">Sides</a>
                    <a class="boxitems" href="desserts.html">Desserts</a>
                    <a class="boxitems" href="drinks.html">Drinks</a>
                </ul>
            </div>
        </nav>
    </header>
    <body class="container">
    <div class="flex-container">
            <h2 class="heading">Recommended</h2>
            <div class="flex-item2">
                <img src="images/pizzas/pizza1.jpg" alt="">
                <p class="mainname2"> Margherita
                    <img class="sub-icons" src="/images/icons/vegicon.png" alt="">
                </p>
                <p class="subdetails2">Loaded with Cheese</p>
                <p class="selectcrust2">Select your size & crust</p>
                <div class="dropdown">
                    <div class="select">
                        <span class="selected">Medium Pan</span>
                        <div class="caret"></div>
                    </div>
                    <ul class="menu">
                        <li class="active">Medium Pan</li>
                        <li>Medium San Francisco Style</li>
                        <li>Medium Schezwan Pan</li>
                        <li>Medium Stuffed Crust - Cheese Maxx</li>
                        <li>Medium Stuffed Crust - Veg Kebab</li>
                        <li>Personal Pan</li>
                        <li>Personal San Francisco Style</li>
                        <li>Personal Schezwan Pan</li>
                        <li>Personal Stuffed Crust - Cheese Maxx</li>
                        <li>Personal Stuffed Crust - Veg Kebab</li>
                    </ul>
                </div>
                <p class="price2"> 
                    <button class="customisebtn2">Add <span class="sideprice">&#8377 279</span> </button>
                </p>
            </div>
            <div class="flex-item2">
                <!-- <img src="images/pizzas/pizza1.jpg" alt="">
                <p class="mainname2"> Margherita
                    <img class="sub-icons" src="/images/icons/vegicon.png" alt="">
                </p> -->
                <p class="subdetails2">Loaded with Cheese</p>
                <p class="selectcrust2">Select your size & crust</p>
                <div class="dropdown">
                    <div class="select">
                        <span class="selected">Medium Pan</span>
                        <div class="caret"></div>
                    </div>
                    <ul class="menu">
                        <li class="active">Medium Pan</li>
                        <li>Medium San Francisco Style</li>
                        <li>Medium Schezwan Pan</li>
                        <li>Medium Stuffed Crust - Cheese Maxx</li>
                        <li>Medium Stuffed Crust - Veg Kebab</li>
                        <li>Personal Pan</li>
                        <li>Personal San Francisco Style</li>
                        <li>Personal Schezwan Pan</li>
                        <li>Personal Stuffed Crust - Cheese Maxx</li>
                        <li>Personal Stuffed Crust - Veg Kebab</li>
                    </ul>
                </div>
                <p class="price2"> 
                    <button class="customisebtn2">Add <span class="sideprice">&#8377 279</span> </button>
                </p>
            </div>
            <!-- <div class="flex-item2"><img src="/images/pizzas/pizza2.jpg" alt="">
                <p class="mainname2">Tandoori Paneer
                    <img class="sub-icons" src="/images/icons/vegicon.png" alt="">
                    <img class="spice" src="/images/icons/mildspice.jpg"  alt="">
                </p>
                <p class="subdetails2">Spiced paneer, Onion, Green Capsicum & Red Paprika in Tandoori Sauce</p>
                <p class="selectcrust2">Select your size & crust</p>
                <div class="dropdown">
                    <div class="select">
                        <span class="selected">Medium Pan</span>
                        <div class="caret"></div>
                    </div>
                    <ul class="menu">
                        <li class="active">Medium Pan</li>
                        <li>Medium San Francisco Style</li>
                        <li>Medium Schezwan Pan</li>
                        <li>Medium Stuffed Crust - Cheese Maxx</li>
                        <li>Medium Stuffed Crust - Veg Kebab</li>
                        <li>Personal Pan</li>
                        <li>Personal San Francisco Style</li>
                        <li>Personal Schezwan Pan</li>
                        <li>Personal Stuffed Crust - Cheese Maxx</li>
                        <li>Personal Stuffed Crust - Veg Kebab</li>
                    </ul>
                </div>
                <p class="price2"> 
                    <button class="customisebtn2">Add <span class="sideprice">&#8377 519</span> </button>
                </p>
            </div> -->
            <!-- <div class="flex-item2"><img src="/images/pizzas/pizza3.jpg" alt="">
                <p class="mainname2">Veggie Supreme
                    <img class="sub-icons" src="/images/icons/vegicon.png" alt="">
                </p>
                <p class="subdetails2">Black Olives, Green Capsicum, Mushroom, Onion, Red Paprika, Sweet Corn</p>
                <p class="selectcrust2">Select your size & crust</p>
                <div class="dropdown">
                    <div class="select">
                        <span class="selected">Medium Pan</span>
                        <div class="caret"></div>
                    </div>
                    <ul class="menu">
                        <li class="active">Medium Pan</li>
                        <li>Medium San Francisco Style</li>
                        <li>Medium Schezwan Pan</li>
                        <li>Medium Stuffed Crust - Cheese Maxx</li>
                        <li>Medium Stuffed Crust - Veg Kebab</li>
                        <li>Personal Pan</li>
                        <li>Personal San Francisco Style</li>
                        <li>Personal Schezwan Pan</li>
                        <li>Personal Stuffed Crust - Cheese Maxx</li>
                        <li>Personal Stuffed Crust - Veg Kebab</li>
                    </ul>
                </div>
                <p class="price2"> 
                    <button class="customisebtn2">Add <span class="sideprice">&#8377 589</span> </button>
                </p>
            </div>
            <div class="flex-item2"><img src="/images/pizzas/pizza4.jpg" alt="">
                <p class="mainname2">Double Paneer Supreme
                    <img class="new" src="/images/icons/newicon.png" alt="">
                </p>
                <img class="sub-icons" src="/images/icons/vegicon.png" alt="">
                <img class="spice" src="/images/icons/mildspice.jpg"  alt="">
                <p style="height:35px;" class="subdetails2">Spiced Paneer, Herbed Onion & Green Capsicum, Red Paprika </p>
                <p class="selectcrust2">Select your size & crust</p>
                <div class="dropdown">
                    <div class="select">
                        <span class="selected">Medium Pan</span>
                        <div class="caret"></div>
                    </div>
                    <ul class="menu">
                        <li class="active">Medium Pan</li>
                        <li>Medium San Francisco Style</li>
                        <li>Medium Schezwan Pan</li>
                        <li>Medium Stuffed Crust - Cheese Maxx</li>
                        <li>Medium Stuffed Crust - Veg Kebab</li>
                        <li>Personal Pan</li>
                        <li>Personal San Francisco Style</li>
                        <li>Personal Schezwan Pan</li>
                        <li>Personal Stuffed Crust - Cheese Maxx</li>
                        <li>Personal Stuffed Crust - Veg Kebab</li>
                    </ul>
                </div>
                <p class="price2"> 
                    <button class="customisebtn2">Add <span class="sideprice">&#8377 589</span> </button>
                </p>
            </div>
            <div class="flex-item2"><img src="/images/pizzas/pizza5.jpg" alt="">
                <p class="mainname2">Veg Kebab Surprise
                <img class="new" src="/images/icons/newicon.png" alt="">
                <img class="sub-icons" src="/images/icons/vegicon.png" alt="">
                </p>
                <p class="subdetails2">Veg Kebab, Onion, Green Capsicum, Tomato & Sweet Corn in Tandoori Sauce</p>
                <p class="selectcrust2">Select your size & crust</p>
                <div class="dropdown">
                    <div class="select">
                        <span class="selected">Medium Pan</span>
                        <div class="caret"></div>
                    </div>
                    <ul class="menu">
                        <li class="active">Medium Pan</li>
                        <li>Medium San Francisco Style</li>
                        <li>Medium Schezwan Pan</li>
                        <li>Medium Stuffed Crust - Cheese Maxx</li>
                        <li>Medium Stuffed Crust - Veg Kebab</li>
                        <li>Personal Pan</li>
                        <li>Personal San Francisco Style</li>
                        <li>Personal Schezwan Pan</li>
                        <li>Personal Stuffed Crust - Cheese Maxx</li>
                        <li>Personal Stuffed Crust - Veg Kebab</li>
                    </ul>
                </div>
                <p class="price2"> 
                    <button class="customisebtn2">Add <span class="sideprice">&#8377 519</span> </button>
                </p>
            </div>
            <div class="flex-item2"><img src="/images/pizzas/pizza6.jpg" alt="">
                <p class="mainname2">Chicken Supreme
                    <img class="sub-icons" src="/images/icons/non-vegicon.png" alt="">
                </p>
                <p class="subdetails2">Herbed Chicken, Schezwan Chicken Meatball, Chicken Tikka</p>
                <p class="selectcrust2">Select your size & crust</p>
                <div class="dropdown">
                    <div class="select">
                        <span class="selected">Medium Pan</span>
                        <div class="caret"></div>
                    </div>
                    <ul class="menu">
                        <li class="active">Medium Pan</li>
                        <li>Medium San Francisco Style</li>
                        <li>Medium Schezwan Pan</li>
                        <li>Medium Stuffed Crust - Cheese Maxx</li>
                        <li>Medium Stuffed Crust - Veg Kebab</li>
                        <li>Personal Pan</li>
                        <li>Personal San Francisco Style</li>
                        <li>Personal Schezwan Pan</li>
                        <li>Personal Stuffed Crust - Cheese Maxx</li>
                        <li>Personal Stuffed Crust - Veg Kebab</li>
                    </ul>
                </div>
                <p class="price2"> 
                    <button class="customisebtn2">Add <span class="sideprice">&#8377 629</span> </button>
                </p>
            </div>
            <div class="flex-item2"><img src="/images/pizzas/pizza7.jpg" alt="">
                <p class="mainname2">Chicken Tikka
                    <img class="sub-icons" src="/images/icons/non-vegicon.png" alt="">
                </p>
                <p class="subdetails2">Chicken Tikka, Onion, Tomato</p>
                <p class="selectcrust2">Select your size & crust</p>
                <div class="dropdown">
                    <div class="select">
                        <span class="selected">Medium Pan</span>
                        <div class="caret"></div>
                    </div>
                    <ul class="menu">
                        <li class="active">Medium Pan</li>
                        <li>Medium San Francisco Style</li>
                        <li>Medium Schezwan Pan</li>
                        <li>Medium Stuffed Crust - Cheese Maxx</li>
                        <li>Medium Stuffed Crust - Veg Kebab</li>
                        <li>Personal Pan</li>
                        <li>Personal San Francisco Style</li>
                        <li>Personal Schezwan Pan</li>
                        <li>Personal Stuffed Crust - Cheese Maxx</li>
                        <li>Personal Stuffed Crust - Veg Kebab</li>
                    </ul>
                </div>
                <p class="price2"> 
                    <button class="customisebtn2">Add <span class="sideprice">&#8377 599</span> </button>
                </p>
            </div>
            <div class="flex-item2"><img src="/images/pizzas/pizza8.jpg" alt="">
                <p class="mainname2">Double Chicken Sausage 
                    <img class="sub-icons" src="/images/icons/non-vegicon.png" alt="">
                </p>
                <p class="subdetails2">Chicken Sausage</p>
                <p class="selectcrust2">Select your size & crust</p>
                <div class="dropdown">
                    <div class="select">
                        <span class="selected">Medium Pan</span>
                        <div class="caret"></div>
                    </div>
                    <ul class="menu">
                        <li class="active">Medium Pan</li>
                        <li>Medium San Francisco Style</li>
                        <li>Medium Schezwan Pan</li>
                        <li>Medium Stuffed Crust - Cheese Maxx</li>
                        <li>Medium Stuffed Crust - Veg Kebab</li>
                        <li>Personal Pan</li>
                        <li>Personal San Francisco Style</li>
                        <li>Personal Schezwan Pan</li>
                        <li>Personal Stuffed Crust - Cheese Maxx</li>
                        <li>Personal Stuffed Crust - Veg Kebab</li>
                    </ul>
                </div>
                <p class="price2"> 
                    <button class="customisebtn2">Add <span class="sideprice">&#8377 529</span> </button>
                </p>
            </div> -->
                                                                                                       
            <!-- <h2 class="heading">Favourite</h2>
            <div class="flex-item2"><img src="/images/pizzas/favo1.jpg" alt="">
                <p class="mainname2"> Corn & Cheese
                    <img class="sub-icons" src="/images/icons/vegicon.png" alt="">
                </p>
                <p class="subdetails2">Cheese, Sweet Corn</p>
                <p class="selectcrust2">Select your size & crust</p>
                <div class="dropdown">
                    <div class="select">
                        <span class="selected">Medium Pan</span>
                        <div class="caret"></div>
                    </div>
                    <ul class="menu">
                        <li class="active">Medium Pan</li>
                        <li>Medium San Francisco Style</li>
                        <li>Medium Schezwan Pan</li>
                        <li>Medium Stuffed Crust - Cheese Maxx</li>
                        <li>Medium Stuffed Crust - Veg Kebab</li>
                        <li>Personal Pan</li>
                        <li>Personal San Francisco Style</li>
                        <li>Personal Schezwan Pan</li>
                        <li>Personal Stuffed Crust - Cheese Maxx</li>
                        <li>Personal Stuffed Crust - Veg Kebab</li>
                    </ul>
                </div>
                <p class="price2"> 
                    <button class="customisebtn2">Add <span class="sideprice">&#8377 379</span> </button>
                </p>
            </div>
            <div class="flex-item2"><img src="/images/pizzas/favo2.jpg" alt="">
                <p class="mainname2"> Tandoori Onion
                    <img class="new" src="/images/icons/newicon.png" alt="">
                    <img class="sub-icons" src="/images/icons/vegicon.png" alt="">
                </p>
                <p class="subdetails2">Cheese & Onion in Tandoori Sauce </p>
                <p class="selectcrust2">Select your size & crust</p>
                <div class="dropdown">
                    <div class="select">
                        <span class="selected">Medium Pan</span>
                        <div class="caret"></div>
                    </div>
                    <ul class="menu">
                        <li class="active">Medium Pan</li>
                        <li>Medium San Francisco Style</li>
                        <li>Medium Schezwan Pan</li>
                        <li>Medium Stuffed Crust - Cheese Maxx</li>
                        <li>Medium Stuffed Crust - Veg Kebab</li>
                        <li>Personal Pan</li>
                        <li>Personal San Francisco Style</li>
                        <li>Personal Schezwan Pan</li>
                        <li>Personal Stuffed Crust - Cheese Maxx</li>
                        <li>Personal Stuffed Crust - Veg Kebab</li>
                    </ul>
                </div>
                <p class="price2"> 
                    <button class="customisebtn2">Add <span class="sideprice">&#8377 379</span> </button>
                </p>
            </div>
            <div class="flex-item2"><img src="/images/pizzas/favo3.jpg" alt="">
                <p class="mainname2"> Farmers Pick
                    <img class="sub-icons" src="/images/icons/vegicon.png" alt="">
                </p>
                <p class="subdetails2">Herbed Onion & Green Capsicum, Red Capsicum, Mushroom, Baby Corn</p>
                <p class="selectcrust2">Select your size & crust</p>
                <div class="dropdown">
                    <div class="select">
                        <span class="selected">Medium Pan</span>
                        <div class="caret"></div>
                    </div>
                    <ul class="menu">
                        <li class="active">Medium Pan</li>
                        <li>Medium San Francisco Style</li>
                        <li>Medium Schezwan Pan</li>
                        <li>Medium Stuffed Crust - Cheese Maxx</li>
                        <li>Medium Stuffed Crust - Veg Kebab</li>
                        <li>Personal Pan</li>
                        <li>Personal San Francisco Style</li>
                        <li>Personal Schezwan Pan</li>
                        <li>Personal Stuffed Crust - Cheese Maxx</li>
                        <li>Personal Stuffed Crust - Veg Kebab</li>
                    </ul>
                </div>
                <p class="price2"> 
                    <button class="customisebtn2">Add <span class="sideprice">&#8377 529</span> </button>
                </p>
            </div>
                                                                                                             
            <h2 class="heading">Delight</h2>
            <div class="flex-item2"><img src="/images/pizzas/delight1.jpg" alt="">
                <p class="mainname2"> Double Cheese
                    <img class="sub-icons" src="/images/icons/vegicon.png" alt="">
                </p>
                <p class="subdetails2">Extra Cheese on Cheese</p>
                <p class="selectcrust2">Select your size & crust</p>
                <div class="dropdown">
                    <div class="select">
                        <span class="selected">Medium Pan</span>
                        <div class="caret"></div>
                    </div>
                    <ul class="menu">
                        <li class="active">Medium Pan</li>
                        <li>Medium San Francisco Style</li>
                        <li>Medium Schezwan Pan</li>
                        <li>Medium Stuffed Crust - Cheese Maxx</li>
                        <li>Medium Stuffed Crust - Veg Kebab</li>
                        <li>Personal Pan</li>
                        <li>Personal San Francisco Style</li>
                        <li>Personal Schezwan Pan</li>
                        <li>Personal Stuffed Crust - Cheese Maxx</li>
                        <li>Personal Stuffed Crust - Veg Kebab</li>
                    </ul>
                </div>
                <p class="price2"> 
                    <button class="customisebtn2">Add <span class="sideprice">&#8377 439</span> </button>
                </p>
            </div>
            <div class="flex-item2"><img src="/images/pizzas/delight2.jpg" alt="">
                <p class="mainname2"> Spiced Paneer
                    <img class="sub-icons" src="/images/icons/vegicon.png" alt="">
                </p>
                <p class="subdetails2">Masala Paneer, Onion, Tomato</p>
                <p class="selectcrust2">Select your size & crust</p>
                <div class="dropdown">
                    <div class="select">
                        <span class="selected">Medium Pan</span>
                        <div class="caret"></div>
                    </div>
                    <ul class="menu">
                        <li class="active">Medium Pan</li>
                        <li>Medium San Francisco Style</li>
                        <li>Medium Schezwan Pan</li>
                        <li>Medium Stuffed Crust - Cheese Maxx</li>
                        <li>Medium Stuffed Crust - Veg Kebab</li>
                        <li>Personal Pan</li>
                        <li>Personal San Francisco Style</li>
                        <li>Personal Schezwan Pan</li>
                        <li>Personal Stuffed Crust - Cheese Maxx</li>
                        <li>Personal Stuffed Crust - Veg Kebab</li>
                    </ul>
                </div>
                <p class="price2"> 
                    <button class="customisebtn2">Add <span class="sideprice">&#8377 439</span> </button>
                </p>
            </div>
            <div class="flex-item2"><img src="/images/pizzas/delight3.jpg" alt="">
                <p class="mainname2"> Veggie Feast
                    <img class="sub-icons" src="/images/icons/vegicon.png" alt="">
                </p>
                <p class="subdetails2">Herbed Onion & Green Capsicum, Sweet Corn</p>
                <p class="selectcrust2">Select your size & crust</p>
                <div class="dropdown">
                    <div class="select">
                        <span class="selected">Medium Pan</span>
                        <div class="caret"></div>
                    </div>
                    <ul class="menu">
                        <li class="active">Medium Pan</li>
                        <li>Medium San Francisco Style</li>
                        <li>Medium Schezwan Pan</li>
                        <li>Medium Stuffed Crust - Cheese Maxx</li>
                        <li>Medium Stuffed Crust - Veg Kebab</li>
                        <li>Personal Pan</li>
                        <li>Personal San Francisco Style</li>
                        <li>Personal Schezwan Pan</li>
                        <li>Personal Stuffed Crust - Cheese Maxx</li>
                        <li>Personal Stuffed Crust - Veg Kebab</li>
                    </ul>
                </div>
                <p class="price2"> 
                    <button class="customisebtn2">Add <span class="sideprice">&#8377 439</span> </button>
                </p>
            </div>
            <div class="flex-item2"><img src="/images/pizzas/delight4.jpg" alt="">
                <p class="mainname2"> Veggie Tandoori 
                    <img class="new" src="/images/icons/newicon.png" alt="">
                    <img class="sub-icons" src="/images/icons/vegicon.png" alt="">
                </p>
                <p class="subdetails2">Onion, Green Capsicum & Mushroom in Tandoori Sauce</p>
                <p class="selectcrust2">Select your size & crust</p>
                <div class="dropdown">
                    <div class="select">
                        <span class="selected">Medium Pan</span>
                        <div class="caret"></div>
                    </div>
                    <ul class="menu">
                        <li class="active">Medium Pan</li>
                        <li>Medium San Francisco Style</li>
                        <li>Medium Schezwan Pan</li>
                        <li>Medium Stuffed Crust - Cheese Maxx</li>
                        <li>Medium Stuffed Crust - Veg Kebab</li>
                        <li>Personal Pan</li>
                        <li>Personal San Francisco Style</li>
                        <li>Personal Schezwan Pan</li>
                        <li>Personal Stuffed Crust - Cheese Maxx</li>
                        <li>Personal Stuffed Crust - Veg Kebab</li>
                    </ul>
                </div>
                <p class="price2"> 
                    <button class="customisebtn2">Add <span class="sideprice">&#8377 439</span> </button>
                </p>
            </div>
            <div class="flex-item2"><img src="/images/pizzas/delight5.jpg" alt="">
                <p class="mainname2"> Spiced Chicked Meatballs
                    <img class="sub-icons" src="/images/icons/non-vegicon.png" alt="">
                </p>
                <p class="subdetails2" style="padding-top: 19px;">Schezwan Chicken Meatball, Onion</p>
                <p class="selectcrust2">Select your size & crust</p>
                <div class="dropdown">
                    <div class="select">
                        <span class="selected">Medium Pan</span>
                        <div class="caret"></div>
                    </div>
                    <ul class="menu">
                        <li class="active">Medium Pan</li>
                        <li>Medium San Francisco Style</li>
                        <li>Medium Schezwan Pan</li>
                        <li>Medium Stuffed Crust - Cheese Maxx</li>
                        <li>Medium Stuffed Crust - Veg Kebab</li>
                        <li>Personal Pan</li>
                        <li>Personal San Francisco Style</li>
                        <li>Personal Schezwan Pan</li>
                        <li>Personal Stuffed Crust - Cheese Maxx</li>
                        <li>Personal Stuffed Crust - Veg Kebab</li>
                    </ul>
                </div>
                <p class="price2"> 
                    <button class="customisebtn2">Add <span class="sideprice">&#8377 519</span> </button>
                </p>
            </div>
            <div class="flex-item2"><img src="/images/pizzas/delight6.jpg" alt="">
                <p class="mainname2">Chicken N Corn Delight 
                </p>
                <img class="new" style="padding-top: 5px;" src="/images/icons/newicon.png" alt="">
                <img class="sub-icons" style="padding-left: 5px;" src="/images/icons/non-vegicon.png" alt="">
                <p class="subdetails2">Herbed Chicken, Sweet Corn, Green Capsicum</p>
                <p class="selectcrust2">Select your size & crust</p>
                <div class="dropdown">
                    <div class="select">
                        <span class="selected">Medium Pan</span>
                        <div class="caret"></div>
                    </div>
                    <ul class="menu">
                        <li class="active">Medium Pan</li>
                        <li>Medium San Francisco Style</li>
                        <li>Medium Schezwan Pan</li>
                        <li>Medium Stuffed Crust - Cheese Maxx</li>
                        <li>Medium Stuffed Crust - Veg Kebab</li>
                        <li>Personal Pan</li>
                        <li>Personal San Francisco Style</li>
                        <li>Personal Schezwan Pan</li>
                        <li>Personal Stuffed Crust - Cheese Maxx</li>
                        <li>Personal Stuffed Crust - Veg Kebab</li>
                    </ul>
                </div>
                <p class="price2"> 
                    <button class="customisebtn2">Add <span class="sideprice">&#8377 529</span> </button>
                </p>
            </div> -->
        </div>

    </body>
    <footer>

    </footer>
</body>
</html>