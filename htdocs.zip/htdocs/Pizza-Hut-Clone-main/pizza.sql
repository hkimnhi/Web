SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


CREATE TABLE `sanpham` (
  `MaSP` int(11) NOT NULL,
  `TenSP` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  `DonGia` int(11) NOT NULL,
  `SoLuong` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `HinhAnh` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `MaKM` int(11) NOT NULL,
  `SoSao` int(11) NOT NULL,
  `SoDanhGia` int(11) NOT NULL,
  `TrangThai` int(11) NOT NULL
) 
ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `sanpham` (`MaSP`, `TenSP`, `DonGia`, `SoLuong`, `HinhAnh`, `MaKM`, `SoSao`, `SoDanhGia`, `TrangThai`,`sosize`) VALUES
(1,"seafood pizza", 299000, 10, "images/pizzas/pizza1.jpg", 4, 2, 2, 1,7),
(2,"pepperoni pizza", 299000, 10, "images/pizzas/pizza2.jpg", 4, 2, 2, 1,7),
(3,"hawaiian pizza", 299000, 10, "images/pizzas/pizza3.jpg", 4, 2, 2, 1,7),
(4,"meat lover pizza", 299000, 10, "images/pizzas/pizza4.jpg", 4, 2, 2, 1,7),
(5,"veggie pizza", 299000, 10, "images/pizzas/pizza5.jpg", 4, 2, 2, 1,7),
(6,"cheese pizza", 299000, 10, "images/pizzas/pizza6.jpg", 4, 2, 2, 1,7),
(7,"mushroom pizza", 299000, 10, "images/pizzas/pizza7.jpg", 4, 2, 2, 1,7),
(8,"chicken pizza", 299000, 10, "images/pizzas/pizza8.jpg", 4, 2, 2, 1,7),
(9,"sausage pizza", 299000, 10, "images/pizzas/pizza9.jpg", 4, 2, 2, 1,7),
(10,"bbq chicken pizza", 299000, 10, "images/pizzas/pizza10.jpg", 4, 2, 2, 1,7),
(11,"taco pizza", 299000, 10, "images/pizzas/pizza11.jpg", 4, 2, 2, 1,7),
(12,"spinach pizza", 299000, 10, "images/pizzas/pizza12.jpg", 4, 2, 2, 1,7),
(13,"buffalo chicken pizza", 299000, 10, "images/pizzas/pizza13.jpg", 4, 2, 2, 1,7),
(14,"garlic pizza", 299000, 10, "images/pizzas/pizza14.jpg", 4, 2, 2, 1,7),
(15,"peanut butter pizza", 299000, 10, "images/pizzas/pizza15.jpg", 4, 2, 2, 1,7),
(16,"chocolate pizza", 299000, 10, "images/pizzas/pizza16.jpg", 4, 2, 2, 1,7),
(17,"fruit pizza", 299000, 10, "images/pizzas/pizza17.jpg", 4, 2, 2, 1,7),
(18,"dessert pizza", 299000, 10, "images/pizzas/pizza18.jpg", 4, 2, 2, 1,7),
(19,"mexican pizza", 299000, 10, "images/pizzas/pizza19.jpg", 4, 2, 2, 1,7),
(20,"greek pizza", 299000, 10, "images/pizzas/pizza20.jpg", 4, 2, 2, 1,7);

ALTER TABLE `sanpham`
  ADD PRIMARY KEY (`MaSP`);

CREATE TABLE `size`{
  `Msize` int(11) NOT NULL,
  `ten_size` varchar(70) COLLATE utf8_unicode_ci 
}
ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO `size` (`Msize`,`ten_size`)VALUES
(1,'Medium Pan'),
(2,'Medium San Francisco Style'),
(3,'Medium Schezwan Pan'),
(4,'Medium Stuffed Crust - Cheese Maxx'),
(5,'Medium Stuffed Crust - Veg Kebab'),
(6,'Personal Pan'),
(7,'Personal San Francisco Style'),
(8,'Personal Schezwan Pan'),
(9,'Personal Stuffed Crust - Cheese Maxx'),
(10,'Personal Stuffed Crust - Veg Kebab');

COMMIT;