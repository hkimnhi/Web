URLajax();
function URLajax(){
    $.ajax({
        type: "GET",
        url: "../getsanpham.php",
        dataType: "json",
        data:{
            reguest:"getsp"
        },
        success: function(data){
           addtoweb(data);
        }
    });
}
function getsize(quantity){
    $.ajax({
        type: "GET",
        url: "../getsanpham.php",
        dataType: "json",
        data:{
            reguest:"getsize",
            quantity:quantity
        },
        success: function(data){
            return data;
        }
    });
}
function addtoweb(data){
    var a=document.querySelector('.flex-container');
    var s=`<h2 class="heading">Recommended</h2>`;
    
    for(var i=0;i<data.length;i++){
        s+=`
        <div class="flex-item2">
            <img src='${data[i].HinhAnh}'>
            <p class="mainname2">${data[i].TenSP}</p>
            <p class="subdetails2">Loaded with Cheese</p>
            <p class="selectcrust2">Select your size & crust</p>
                <div class="dropdown">
                    <div class="select">
                        <span class="selected">Medium Pan</span>
                        <div class="caret"></div>
                    </div> `
                s+=`<ul class="menu">`
            $size=getsize(data[i].sosize);
            for(var j=0;j<$size.length;j++){
                if(j==0){
                    s+=`<li class="active">${$size[j].ten_size}</li>`
                }
                else{
                    s+=`<li>${$size[j].ten_size}</li>`
                }
            }
                s+=`</ul>`


            s+=`</div>
        </div>`;
    }
        a.innerHTML=s;
}