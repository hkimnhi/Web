<?php  
session_start();
require_once("DB_classes.php");
if(isset($_GET['reguest']) )
    switch ($_GET['reguest']) {
        case 'getsp':
            $dssp = (new SanPhamBUS())->select_all();
            die (json_encode($dssp));
            break;
        case 'getsize':
            $dssize = (new SizeBUS())->get_size('quantity');
            die (json_encode($dssize));
            break;
    }
 ?>